
import React, { useState } from "react";
import { motion } from "framer-motion";

const products = [
  { name: "Raw Makhana", description: "Premium quality raw makhana, carefully sourced and sorted.", price: "$10" },
  { name: "Mint Flavour", description: "Refreshing mint flavored roasted makhana, a healthy snack.", price: "$12" },
  { name: "Spicy Flavour", description: "Bold and spicy roasted makhana, full of flavor.", price: "$12" },
  { name: "Ghee Roasted", description: "Traditional ghee roasted makhana, rich in taste and nutrition.", price: "$14" },
  { name: "Classic Salt", description: "Simply salted makhana for the purists, light and tasty.", price: "$11" },
];

const galleryImages = [
  "/images/packaging.jpg",
  "/images/factory.jpg",
  "/images/flavours.jpg",
  "/images/raw.jpg",
];

export default function RoyalFoxnutsApp() {
  const [formData, setFormData] = useState({ name: "", email: "", phone: "", message: "" });
  const [status, setStatus] = useState("");
  const [cart, setCart] = useState([]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("Sending...");
    try {
      const response = await fetch("https://formspree.io/f/xwkgywjj", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });
      if (response.ok) {
        setStatus("Message sent successfully!");
        setFormData({ name: "", email: "", phone: "", message: "" });
      } else {
        setStatus("Failed to send message. Please try again.");
      }
    } catch (error) {
      setStatus("Something went wrong. Please try again later.");
    }
  };

  const addToCart = (product) => setCart([...cart, product]);
  const removeFromCart = (i) => setCart(cart.filter((_, idx) => idx !== i));

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-green-100 py-6 shadow-md">
        <div className="container mx-auto px-6 flex justify-between items-center">
          <h1 className="text-3xl font-bold text-green-900">Royal Foxnuts</h1>
          <span className="text-sm">10 Years of Purity & Taste</span>
        </div>
      </header>

      <main className="container mx-auto px-6 py-10 space-y-16">
        <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-center">
          <h2 className="text-4xl font-semibold text-green-800 mb-4">Our Products</h2>
          <p className="text-lg text-gray-600 max-w-xl mx-auto">Discover our range of healthy and tasty makhana products, from raw to exotic flavored options.</p>
        </motion.section>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product, index) => (
            <div key={index} className="rounded-2xl shadow-md p-6 space-y-2 border">
              <h3 className="text-xl font-semibold text-green-700">{product.name}</h3>
              <p className="text-gray-600">{product.description}</p>
              <p className="text-green-800 font-medium">{product.price}</p>
              <button className="mt-2 bg-green-600 text-white px-4 py-2 rounded" onClick={() => addToCart(product)}>Add to Cart</button>
            </div>
          ))}
        </div>

        {cart.length > 0 && (
          <section className="bg-orange-50 rounded-xl p-6 shadow-md">
            <h2 className="text-2xl font-semibold text-orange-800 mb-4">Your Cart</h2>
            <ul className="space-y-2">
              {cart.map((item, index) => (
                <li key={index} className="flex justify-between items-center">
                  <span>{item.name} - {item.price}</span>
                  <button className="text-red-500 text-sm" onClick={() => removeFromCart(index)}>Remove</button>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section>
          <h2 className="text-3xl font-semibold text-green-800 text-center mb-6">Product Gallery</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {galleryImages.map((src, idx) => (
              <img key={idx} src={src} alt={`Gallery image ${idx + 1}`} className="rounded-xl shadow-md hover:scale-105 transition-transform duration-300" />
            ))}
          </div>
        </section>

        <section className="bg-green-50 rounded-xl p-8 shadow-md">
          <h2 className="text-3xl font-semibold text-green-800 mb-4 text-center">Contact Us</h2>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <input name="name" value={formData.name} onChange={handleInputChange} placeholder="Name" required className="p-2 border rounded" />
            <input name="email" type="email" value={formData.email} onChange={handleInputChange} placeholder="Email" required className="p-2 border rounded" />
            <input name="phone" type="tel" value={formData.phone} onChange={handleInputChange} placeholder="Phone Number" className="p-2 border rounded" />
            <textarea name="message" value={formData.message} onChange={handleInputChange} placeholder="Your message" required className="p-2 border rounded md:col-span-2" />
            <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded md:col-span-2">Send Message</button>
            {status && <p className="md:col-span-2 text-sm text-center text-green-700">{status}</p>}
          </form>
        </section>
      </main>

      <footer className="bg-green-100 text-center py-6 mt-12">
        <p className="text-sm text-green-800">© 2025 Royal Foxnuts. All rights reserved. | Since 2015</p>
      </footer>
    </div>
  );
}
